FieldShield inspection review package
=====================================
Inspection: FS-DEMO-0001 - Demo — hail, wind and roof-leak inspection
Exported: 2026-10-13T15:36:46.896Z
NOTE: This package contains FICTIONAL demonstration data only.

Contents
--------
report.pdf                 Latest inspection report (watermarked DRAFT unless final review is complete)
measurement-worksheet.pdf  Measurement worksheet with dimensions as entered, formulas and value sources
measurement-worksheet.csv  Same data as CSV for review
photo-index.pdf            Numbered photo index with images and captions
photo-index.csv            Photo index as CSV
qc-summary.pdf             Estimate quality-control summary (if estimate data was entered)
qc-findings.csv            QC findings with dispositions
photos/originals/          Original photographs exactly as captured/imported
photos/annotated/          Annotated copies (originals are never modified)
inspection-data.json       Complete structured inspection record (FieldShield backup format)

Important
---------
- This package was generated on the user's device. FieldShield did not upload it anywhere.
- Store and share it only in systems approved by your employer.
- FieldShield does not make coverage decisions and has no Xactimate integration.
